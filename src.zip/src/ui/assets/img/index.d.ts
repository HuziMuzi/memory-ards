declare module "*.gif";
declare module "*.png";
