export type TIconProps = {
    onClick?: () => void;
};
